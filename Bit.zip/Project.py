
""" Master Project File
"""

import Author
import CAAuthor
import CLsAuthor
import ClsAu
import SAText
import SMFinder

exec(Author)
exec(CAAuthor)
exec(SAText)