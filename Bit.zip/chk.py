import CLsAuthor
import ClsAu

Past = exec(CLsAuthor)
Text = exec(ClsAu)

if Past == Text:
    print("UnBiased")
else:
    print("Biased")